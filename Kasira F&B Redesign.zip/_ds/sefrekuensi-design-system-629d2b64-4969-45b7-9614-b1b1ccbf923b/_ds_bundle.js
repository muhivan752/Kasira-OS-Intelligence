/* @ds-bundle: {"format":3,"namespace":"SEFREKUENSIDesignSystem_629d2b","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"InterestTag","sourcePath":"components/display/InterestTag.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"ChatBubble","sourcePath":"components/signature/ChatBubble.jsx"},{"name":"FrequencyMeter","sourcePath":"components/signature/FrequencyMeter.jsx"},{"name":"ProfileCard","sourcePath":"components/signature/ProfileCard.jsx"},{"name":"RoomCard","sourcePath":"components/signature/RoomCard.jsx"}],"sourceHashes":{"components/core/Button.jsx":"15970a0971cf","components/core/IconButton.jsx":"79297d21efa0","components/display/Avatar.jsx":"14e730d3c9b4","components/display/Badge.jsx":"fa7ed5fc5952","components/display/Card.jsx":"f91812cbc2ef","components/display/InterestTag.jsx":"5c30c7b6fa1d","components/forms/Input.jsx":"900b8927fcc9","components/forms/Switch.jsx":"5963849deb69","components/navigation/Tabs.jsx":"b300f47f45f6","components/signature/ChatBubble.jsx":"9a8c10fd9a1d","components/signature/FrequencyMeter.jsx":"bf0a948b6d12","components/signature/ProfileCard.jsx":"81df457b978e","components/signature/RoomCard.jsx":"262eb58a5b04","ui_kits/_shared/shell.jsx":"baa3603575d9","ui_kits/chat/app.jsx":"82e97b135d76","ui_kits/chat/rooms.jsx":"862d321b6ae9","ui_kits/chat/screens.jsx":"cbae3f82d491","ui_kits/discover/app.jsx":"b5ad3d97db92","ui_kits/discover/screens.jsx":"c5ce83a92b1c","ui_kits/onboarding/app.jsx":"c35d237d2bf3","ui_kits/onboarding/screens.jsx":"ae2ad291285c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SEFREKUENSIDesignSystem_629d2b = window.SEFREKUENSIDesignSystem_629d2b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SEFREKUENSI — Button
 * Brand-forward button. `primary` uses the signature pink→violet gradient
 * with a soft neon glow; other variants stay calm so primary always wins.
 */
function Button({
  children,
  variant = 'primary',
  // primary | secondary | soft | outline | ghost | danger
  size = 'md',
  // sm | md | lg
  full = false,
  pill = true,
  disabled = false,
  loading = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      fontSize: 13,
      padding: '8px 16px',
      gap: 6,
      minH: 36
    },
    md: {
      fontSize: 15,
      padding: '11px 22px',
      gap: 8,
      minH: 44
    },
    lg: {
      fontSize: 16,
      padding: '15px 28px',
      gap: 10,
      minH: 54
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: 'var(--gradient-frekuensi)',
      color: 'var(--text-on-brand)',
      border: '1px solid transparent',
      boxShadow: 'var(--glow-brand)'
    },
    secondary: {
      background: 'var(--brand-secondary)',
      color: 'var(--text-on-brand)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    },
    soft: {
      background: 'var(--brand-tint)',
      color: 'var(--brand-primary)',
      border: '1px solid transparent',
      boxShadow: 'none'
    },
    outline: {
      background: 'transparent',
      color: 'var(--text-strong)',
      border: '1.5px solid var(--border-default)',
      boxShadow: 'none'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-body)',
      border: '1px solid transparent',
      boxShadow: 'none'
    },
    danger: {
      background: 'var(--danger)',
      color: '#fff',
      border: '1px solid transparent',
      boxShadow: 'none'
    }
  };
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    onClick: onClick,
    disabled: disabled || loading,
    className: "sf-focusable",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      width: full ? '100%' : 'auto',
      minHeight: s.minH,
      padding: s.padding,
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: s.fontSize,
      lineHeight: 1,
      letterSpacing: '-0.005em',
      borderRadius: pill ? 'var(--radius-pill)' : 'var(--radius-md)',
      cursor: disabled || loading ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'transform var(--dur-fast) var(--ease-spring), box-shadow var(--dur-base) var(--ease-out), filter var(--dur-base)',
      WebkitTapHighlightColor: 'transparent',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled && !loading) e.currentTarget.style.transform = 'scale(var(--press-scale))';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), loading && /*#__PURE__*/React.createElement(Spinner, null), !loading && iconLeft, children, !loading && iconRight);
}
function Spinner() {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: 15,
      height: 15,
      borderRadius: '50%',
      border: '2px solid rgba(255,255,255,0.45)',
      borderTopColor: '#fff',
      display: 'inline-block',
      animation: 'sf-spin 0.7s linear infinite'
    }
  });
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SEFREKUENSI — IconButton
 * Square/circular button for a single icon. Used for like/pass actions,
 * toolbar controls, and chat affordances. Pass a Lucide icon as children.
 */
function IconButton({
  children,
  variant = 'soft',
  // primary | soft | outline | ghost | glass
  size = 'md',
  // sm | md | lg | xl
  round = true,
  disabled = false,
  label,
  // aria-label (required for a11y)
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 36,
    md: 44,
    lg: 56,
    xl: 68
  };
  const dim = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: 'var(--gradient-frekuensi)',
      color: '#fff',
      border: '1px solid transparent',
      boxShadow: 'var(--glow-brand)'
    },
    soft: {
      background: 'var(--surface-card)',
      color: 'var(--text-strong)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-sm)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--text-strong)',
      border: '1.5px solid var(--border-default)',
      boxShadow: 'none'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-body)',
      border: '1px solid transparent',
      boxShadow: 'none'
    },
    glass: {
      background: 'rgba(255,255,255,0.16)',
      color: '#fff',
      border: '1px solid rgba(255,255,255,0.28)',
      boxShadow: 'none',
      backdropFilter: 'blur(10px)'
    }
  };
  const v = variants[variant] || variants.soft;
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": label,
    onClick: onClick,
    disabled: disabled,
    className: "sf-focusable",
    style: {
      width: dim,
      height: dim,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: round ? 'var(--radius-pill)' : 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'transform var(--dur-fast) var(--ease-spring), box-shadow var(--dur-base)',
      WebkitTapHighlightColor: 'transparent',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.9)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/display/Avatar.jsx
try { (() => {
/**
 * SEFREKUENSI — Avatar
 * Round avatar with optional status dot and gradient "active" ring.
 * Falls back to initials on a tinted background.
 */
function Avatar({
  src,
  name = '',
  size = 'md',
  // xs | sm | md | lg | xl
  status,
  // online | away | offline
  ring = false,
  // gradient activity ring
  style = {}
}) {
  const sizes = {
    xs: 28,
    sm: 36,
    md: 48,
    lg: 64,
    xl: 88
  };
  const dim = sizes[size] || sizes.md;
  const initials = name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const statusColor = {
    online: 'var(--status-online)',
    away: 'var(--status-away)',
    offline: 'var(--status-offline)'
  }[status];
  const dotSize = Math.max(8, dim * 0.26);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: dim,
      height: dim,
      flexShrink: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      borderRadius: '50%',
      padding: ring ? Math.max(2, dim * 0.05) : 0,
      background: ring ? 'var(--gradient-frekuensi)' : 'transparent',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      borderRadius: '50%',
      overflow: 'hidden',
      border: ring ? '2px solid var(--surface-card)' : '0',
      background: src ? 'var(--surface-sunken)' : 'var(--brand-tint)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: dim * 0.38,
      color: 'var(--brand-primary)'
    }
  }, initials || '?'))), status && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 0,
      bottom: 0,
      width: dotSize,
      height: dotSize,
      borderRadius: '50%',
      background: statusColor,
      border: '2px solid var(--surface-card)',
      boxShadow: status === 'online' ? 'var(--glow-mint)' : 'none'
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
/**
 * SEFREKUENSI — Badge
 * Compact label / count. Use `gradient` for brand emphasis, `soft`/semantic
 * for status. Optional leading dot.
 */
function Badge({
  children,
  variant = 'soft',
  // gradient | soft | neutral | success | warning | danger | info
  dot = false,
  size = 'md',
  // sm | md
  style = {}
}) {
  const variants = {
    gradient: {
      background: 'var(--gradient-frekuensi)',
      color: '#fff',
      border: '1px solid transparent'
    },
    soft: {
      background: 'var(--brand-tint)',
      color: 'var(--brand-primary)',
      border: '1px solid transparent'
    },
    neutral: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-body)',
      border: '1px solid var(--border-subtle)'
    },
    success: {
      background: 'color-mix(in srgb, var(--success) 16%, transparent)',
      color: 'var(--success)',
      border: '1px solid transparent'
    },
    warning: {
      background: 'color-mix(in srgb, var(--warning) 18%, transparent)',
      color: 'var(--warning)',
      border: '1px solid transparent'
    },
    danger: {
      background: 'color-mix(in srgb, var(--danger) 14%, transparent)',
      color: 'var(--danger)',
      border: '1px solid transparent'
    },
    info: {
      background: 'color-mix(in srgb, var(--info) 14%, transparent)',
      color: 'var(--info)',
      border: '1px solid transparent'
    }
  };
  const v = variants[variant] || variants.soft;
  const dotColor = {
    success: 'var(--success)',
    warning: 'var(--warning)',
    danger: 'var(--danger)',
    info: 'var(--info)',
    soft: 'var(--brand-primary)',
    gradient: '#fff'
  }[variant] || 'var(--text-muted)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: size === 'sm' ? '3px 9px' : '5px 12px',
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: size === 'sm' ? 11 : 12,
      letterSpacing: '0.01em',
      lineHeight: 1.2,
      borderRadius: 'var(--radius-pill)',
      whiteSpace: 'nowrap',
      ...v,
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: dotColor
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SEFREKUENSI — Card
 * Generic surface container. `elevation` controls shadow; `interactive`
 * adds a hover lift. `glow` adds the brand glow for featured cards.
 */
function Card({
  children,
  padding = 'var(--pad-card)',
  radius = 'var(--radius-lg)',
  elevation = 'sm',
  // none | sm | md | lg
  interactive = false,
  glow = false,
  onClick,
  style = {},
  ...rest
}) {
  const shadow = glow ? 'var(--glow-brand)' : {
    none: 'none',
    sm: 'var(--shadow-sm)',
    md: 'var(--shadow-md)',
    lg: 'var(--shadow-lg)'
  }[elevation];
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: radius,
      padding,
      boxShadow: shadow,
      cursor: interactive || onClick ? 'pointer' : 'default',
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base)',
      ...style
    },
    onMouseEnter: e => {
      if (interactive) {
        e.currentTarget.style.transform = 'translateY(var(--hover-lift))';
        e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
      }
    },
    onMouseLeave: e => {
      if (interactive) {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = shadow;
      }
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/InterestTag.jsx
try { (() => {
/**
 * SEFREKUENSI — InterestTag
 * The hobi / "frekuensi" chip. Selectable: tap to toggle. Selected fills with
 * the signature gradient. Optional Lucide icon. Shared interests get `match`.
 */
function InterestTag({
  children,
  icon = null,
  selected = false,
  match = false,
  // highlight as a SHARED interest (mint outline)
  onClick,
  size = 'md',
  // sm | md
  style = {}
}) {
  const interactive = !!onClick;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 7,
    padding: size === 'sm' ? '6px 12px' : '9px 16px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    fontSize: size === 'sm' ? 13 : 14,
    lineHeight: 1,
    borderRadius: 'var(--radius-pill)',
    cursor: interactive ? 'pointer' : 'default',
    transition: 'transform var(--dur-fast) var(--ease-spring), background var(--dur-base), border-color var(--dur-base)',
    WebkitTapHighlightColor: 'transparent',
    whiteSpace: 'nowrap'
  };
  let look;
  if (selected) {
    look = {
      background: 'var(--gradient-frekuensi)',
      color: '#fff',
      border: '1.5px solid transparent',
      boxShadow: 'var(--glow-pink)'
    };
  } else if (match) {
    look = {
      background: 'color-mix(in srgb, var(--accent-neon) 14%, transparent)',
      color: 'var(--mint-600)',
      border: '1.5px solid var(--accent-neon)'
    };
  } else {
    look = {
      background: 'var(--surface-card)',
      color: 'var(--text-body)',
      border: '1.5px solid var(--border-default)'
    };
  }
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    className: "sf-focusable",
    style: {
      ...base,
      ...look,
      ...style
    },
    onMouseDown: e => {
      if (interactive) e.currentTarget.style.transform = 'scale(0.94)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, match && !selected && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--accent-neon)'
    }
  }), icon, children);
}
Object.assign(__ds_scope, { InterestTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/InterestTag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SEFREKUENSI — Input
 * Text field with optional leading icon, label and helper/error text.
 * Focus shows the violet ring; error swaps to danger.
 */
function Input({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  iconLeft = null,
  iconRight = null,
  helper,
  error,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const fieldId = id || React.useId();
  const borderColor = error ? 'var(--danger)' : focused ? 'var(--brand-secondary)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-strong)',
      letterSpacing: '-0.005em'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '0 14px',
      minHeight: 48,
      background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
      border: `1.5px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focused && !error ? 'var(--ring-focus)' : 'none',
      transition: 'border-color var(--dur-base), box-shadow var(--dur-base)',
      opacity: disabled ? 0.6 : 1
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'flex'
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      fontWeight: 500,
      color: 'var(--text-strong)',
      minWidth: 0,
      padding: '12px 0'
    }
  }, rest)), iconRight && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'flex'
    }
  }, iconRight)), (helper || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      fontWeight: 500,
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
/**
 * SEFREKUENSI — Switch
 * On/off toggle. On = signature gradient track. Springy thumb travel.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  size = 'md',
  // sm | md
  label,
  style = {}
}) {
  const dims = size === 'sm' ? {
    w: 40,
    h: 24,
    thumb: 18,
    pad: 3
  } : {
    w: 52,
    h: 30,
    thumb: 24,
    pad: 3
  };
  const toggle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  const track = /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    onClick: toggle,
    disabled: disabled,
    className: "sf-focusable",
    style: {
      width: dims.w,
      height: dims.h,
      flexShrink: 0,
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      padding: dims.pad,
      cursor: disabled ? 'not-allowed' : 'pointer',
      background: checked ? 'var(--gradient-frekuensi)' : 'var(--neutral-300)',
      boxShadow: checked ? 'var(--glow-pink)' : 'inset 0 1px 2px rgba(0,0,0,0.12)',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--dur-base) var(--ease-out), box-shadow var(--dur-base)',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: dims.thumb,
      height: dims.thumb,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: 'var(--shadow-sm)',
      transform: `translateX(${checked ? dims.w - dims.thumb - dims.pad * 2 : 0}px)`,
      transition: 'transform var(--dur-base) var(--ease-spring)'
    }
  }));
  if (!label) return track;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, track, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/**
 * SEFREKUENSI — Tabs (segmented control)
 * Pill segmented control. The active segment slides under the label with the
 * signature gradient. Use for view switches (Untukmu / Terdekat / Online).
 */
function Tabs({
  items = [],
  // [{ id, label, icon? }]
  value,
  onChange,
  size = 'md',
  // sm | md
  style = {}
}) {
  const pad = size === 'sm' ? 4 : 5;
  const segPad = size === 'sm' ? '7px 14px' : '10px 18px';
  const fontSize = size === 'sm' ? 13 : 14;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      position: 'relative',
      background: 'var(--surface-sunken)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-pill)',
      padding: pad,
      gap: 2,
      ...style
    }
  }, items.map(it => {
    const active = it.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      type: "button",
      onClick: () => onChange && onChange(it.id),
      className: "sf-focusable",
      style: {
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: segPad,
        border: 'none',
        cursor: 'pointer',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-sans)',
        fontWeight: 700,
        fontSize,
        color: active ? 'var(--text-on-brand)' : 'var(--text-muted)',
        background: active ? 'var(--gradient-frekuensi)' : 'transparent',
        boxShadow: active ? 'var(--glow-pink)' : 'none',
        transition: 'color var(--dur-base), background var(--dur-base) var(--ease-out)',
        whiteSpace: 'nowrap',
        WebkitTapHighlightColor: 'transparent'
      }
    }, it.icon, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/signature/ChatBubble.jsx
try { (() => {
/**
 * SEFREKUENSI — ChatBubble
 * One message. `sent` = the signature gradient on the right; `received` =
 * surface on the left. Optional time + read state. Group with `tail`.
 */
function ChatBubble({
  children,
  side = 'received',
  // sent | received
  time,
  read = false,
  tail = true,
  // show the corner tail (last in a group)
  style = {}
}) {
  const sent = side === 'sent';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: sent ? 'flex-end' : 'flex-start',
      gap: 3,
      maxWidth: '78%',
      alignSelf: sent ? 'flex-end' : 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 14px',
      background: sent ? 'var(--gradient-frekuensi)' : 'var(--surface-card)',
      color: sent ? '#fff' : 'var(--text-strong)',
      border: sent ? '1px solid transparent' : '1px solid var(--border-subtle)',
      borderRadius: 18,
      borderBottomRightRadius: sent && tail ? 5 : 18,
      borderBottomLeftRadius: !sent && tail ? 5 : 18,
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      fontWeight: 500,
      lineHeight: 1.4,
      boxShadow: sent ? 'var(--glow-pink)' : 'var(--shadow-xs)',
      wordBreak: 'break-word'
    }
  }, children), (time || read) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      padding: '0 4px'
    }
  }, time && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, time), sent && read && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check-check",
    style: {
      width: 13,
      height: 13,
      color: 'var(--brand-secondary)'
    }
  }), sent && !read && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check",
    style: {
      width: 13,
      height: 13,
      color: 'var(--text-muted)'
    }
  })));
}
Object.assign(__ds_scope, { ChatBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/signature/ChatBubble.jsx", error: String((e && e.message) || e) }); }

// components/signature/FrequencyMeter.jsx
try { (() => {
/**
 * SEFREKUENSI — FrequencyMeter
 * The signature compatibility readout. An equalizer of bars "tunes" up to the
 * match level (gradient = in tune, muted = not yet). Echoes the logomark.
 */
function FrequencyMeter({
  value = 72,
  // 0–100 match %
  bars = 18,
  size = 'md',
  // sm | md | lg
  showLabel = true,
  label = 'Frekuensi cocok',
  style = {}
}) {
  const dims = {
    sm: {
      h: 28,
      bw: 3,
      gap: 3,
      num: 22
    },
    md: {
      h: 40,
      bw: 4,
      gap: 4,
      num: 30
    },
    lg: {
      h: 56,
      bw: 5,
      gap: 5,
      num: 42
    }
  }[size] || {
    h: 40,
    bw: 4,
    gap: 4,
    num: 30
  };
  const filled = Math.round(value / 100 * bars);
  // Stable waveform silhouette (symmetric-ish peaks) so it reads as a signal.
  const pattern = [0.35, 0.6, 0.45, 0.8, 0.55, 1, 0.7, 0.5, 0.9, 0.65, 0.85, 0.5, 0.75, 0.45, 0.95, 0.6, 0.4, 0.7];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, showLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      lineHeight: 1,
      fontSize: dims.num,
      color: 'var(--brand-primary)'
    }
  }, Math.round(value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: dims.num * 0.45,
      color: 'var(--text-muted)'
    }
  }, "%"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: dims.gap,
      height: dims.h
    }
  }, Array.from({
    length: bars
  }).map((_, i) => {
    const on = i < filled;
    const barH = Math.max(dims.bw, pattern[i % pattern.length] * dims.h);
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        width: dims.bw,
        height: barH,
        borderRadius: dims.bw,
        background: on ? 'var(--gradient-frekuensi)' : 'var(--border-default)',
        boxShadow: on && i === filled - 1 ? 'var(--glow-pink)' : 'none',
        transition: 'background var(--dur-base), height var(--dur-base) var(--ease-out)'
      }
    });
  })));
}
Object.assign(__ds_scope, { FrequencyMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/signature/FrequencyMeter.jsx", error: String((e && e.message) || e) }); }

// components/signature/ProfileCard.jsx
try { (() => {
/**
 * SEFREKUENSI — ProfileCard
 * The swipe/matching card. Full-bleed photo, protection scrim, name/age,
 * distance, shared interests and the FrequencyMeter. `stamp` shows the
 * LIKE / NOPE overlay while dragging (the kit drives drag/position).
 */
function ProfileCard({
  photo,
  name = '',
  age,
  distance,
  online = false,
  verified = false,
  match = 80,
  interests = [],
  // [{ label, shared? }]
  bio,
  stamp = null,
  // 'like' | 'nope' | null
  width = 340,
  height = 480,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width,
      height,
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      background: 'var(--surface-sunken)',
      boxShadow: 'var(--shadow-xl)',
      userSelect: 'none',
      ...style
    }
  }, photo ? /*#__PURE__*/React.createElement("img", {
    src: photo,
    alt: name,
    draggable: false,
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--gradient-aurora)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(to top, rgba(18,11,25,0.92) 0%, rgba(18,11,25,0.45) 32%, transparent 58%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 14,
      left: 14,
      right: 14,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, distance != null && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      background: 'rgba(255,255,255,0.16)',
      backdropFilter: 'blur(10px)',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "map-pin",
    style: {
      width: 13,
      height: 13
    }
  }), " ", distance, " km"), online && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      background: 'rgba(18,224,160,0.18)',
      backdropFilter: 'blur(10px)',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--mint-400)',
      boxShadow: '0 0 8px var(--mint-400)'
    }
  }), " Online")), stamp && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 28,
      [stamp === 'like' ? 'left' : 'right']: 22,
      transform: `rotate(${stamp === 'like' ? -14 : 14}deg)`,
      padding: '6px 16px',
      borderRadius: 'var(--radius-md)',
      border: `3px solid ${stamp === 'like' ? 'var(--mint-400)' : 'var(--red-400)'}`,
      color: stamp === 'like' ? 'var(--mint-400)' : 'var(--red-400)',
      fontFamily: 'var(--font-display)',
      fontWeight: 900,
      fontSize: 28,
      letterSpacing: '0.04em',
      textShadow: '0 2px 8px rgba(0,0,0,0.3)'
    }
  }, stamp === 'like' ? 'COCOK' : 'LEWAT'), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      padding: 18,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.FrequencyMeter, {
    value: match,
    size: "sm",
    showLabel: false,
    bars: 22,
    style: {
      opacity: 0.95
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 28,
      color: '#fff',
      lineHeight: 1
    }
  }, name), age != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 500,
      fontSize: 24,
      color: 'rgba(255,255,255,0.85)'
    }
  }, age), verified && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "badge-check",
    style: {
      width: 22,
      height: 22,
      color: 'var(--mint-400)'
    }
  })), bio && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 13.5,
      fontWeight: 500,
      color: 'rgba(255,255,255,0.82)',
      lineHeight: 1.45
    }
  }, bio), interests.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 7
    }
  }, interests.slice(0, 4).map((it, i) => it.shared ? /*#__PURE__*/React.createElement(__ds_scope.InterestTag, {
    key: i,
    match: true,
    size: "sm"
  }, it.label) : /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      padding: '6px 12px',
      borderRadius: 'var(--radius-pill)',
      fontSize: 13,
      fontWeight: 600,
      fontFamily: 'var(--font-sans)',
      color: '#fff',
      background: 'rgba(255,255,255,0.16)',
      border: '1px solid rgba(255,255,255,0.22)',
      backdropFilter: 'blur(8px)'
    }
  }, it.label)))));
}
Object.assign(__ds_scope, { ProfileCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/signature/ProfileCard.jsx", error: String((e && e.message) || e) }); }

// components/signature/RoomCard.jsx
try { (() => {
/**
 * SEFREKUENSI — RoomCard
 * A community "ruang" (chat room) tile. Gradient cover with the topic, a live
 * pulse when active, stacked member avatars and the room's frequency tags.
 */
function RoomCard({
  name = '',
  topic,
  members = 0,
  live = false,
  avatars = [],
  // image urls
  tags = [],
  // string[]
  cover = 'var(--gradient-aurora)',
  onClick,
  width = 300,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    className: "sf-focusable",
    style: {
      width,
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-sm)',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base)',
      ...style
    },
    onMouseEnter: e => {
      if (onClick) {
        e.currentTarget.style.transform = 'translateY(-3px)';
        e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
      }
    },
    onMouseLeave: e => {
      if (onClick) {
        e.currentTarget.style.transform = 'translateY(0)';
        e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
      }
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 96,
      background: cover,
      padding: 12,
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between'
    }
  }, topic && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'rgba(255,255,255,0.9)',
      background: 'rgba(0,0,0,0.18)',
      padding: '4px 9px',
      borderRadius: 'var(--radius-pill)',
      backdropFilter: 'blur(6px)'
    }
  }, topic), live && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--font-sans)',
      fontSize: 11,
      fontWeight: 800,
      color: '#fff',
      background: 'rgba(0,0,0,0.25)',
      padding: '4px 10px',
      borderRadius: 'var(--radius-pill)',
      backdropFilter: 'blur(6px)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--mint-400)',
      animation: 'sf-pulse-ring 1.6s infinite'
    }
  }), " LIVE")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 17,
      color: 'var(--text-strong)',
      lineHeight: 1.15
    }
  }, name), tags.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, tags.slice(0, 3).map((t, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--brand-primary)',
      background: 'var(--brand-tint)',
      padding: '4px 10px',
      borderRadius: 'var(--radius-pill)'
    }
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, avatars.slice(0, 4).map((a, i) => /*#__PURE__*/React.createElement("img", {
    key: i,
    src: a,
    alt: "",
    style: {
      width: 28,
      height: 28,
      borderRadius: '50%',
      objectFit: 'cover',
      border: '2px solid var(--surface-card)',
      marginLeft: i === 0 ? 0 : -10
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 8,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-muted)'
    }
  }, members.toLocaleString('id-ID'), " anggota")), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "arrow-right",
    style: {
      width: 18,
      height: 18,
      color: 'var(--text-muted)'
    }
  }))));
}
Object.assign(__ds_scope, { RoomCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/signature/RoomCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/_shared/shell.jsx
try { (() => {
/* SEFREKUENSI — shared phone shell for UI kits */
const {
  useState,
  useEffect,
  useRef
} = React;
function Logomark({
  size = 64
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 64 64",
    xmlns: "http://www.w3.org/2000/svg"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: 'lm' + size,
    x1: "6",
    y1: "6",
    x2: "58",
    y2: "58",
    gradientUnits: "userSpaceOnUse"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#FF2E7E"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "0.5",
    stopColor: "#C03BE6"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#7C3AED"
  }))), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "60",
    height: "60",
    rx: "18",
    fill: 'url(#lm' + size + ')'
  }), /*#__PURE__*/React.createElement("g", {
    fill: "#fff"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "12",
    y: "27",
    width: "5",
    height: "10",
    rx: "2.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "20",
    y: "22",
    width: "5",
    height: "20",
    rx: "2.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "28",
    y: "14",
    width: "5",
    height: "36",
    rx: "2.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "36",
    y: "22",
    width: "5",
    height: "20",
    rx: "2.5"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "44",
    y: "27",
    width: "5",
    height: "10",
    rx: "2.5"
  })), /*#__PURE__*/React.createElement("circle", {
    cx: "30.5",
    cy: "9",
    r: "3.4",
    fill: "#fff"
  }));
}
function StatusBar({
  dark = false
}) {
  const c = dark ? '#fff' : 'var(--text-strong)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      fontFamily: 'var(--font-sans)',
      color: c,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      fontSize: 15
    }
  }, "9:41"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "signal",
    style: {
      width: 16,
      height: 16,
      color: c
    }
  }), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "wifi",
    style: {
      width: 16,
      height: 16,
      color: c
    }
  }), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "battery-full",
    style: {
      width: 22,
      height: 22,
      color: c
    }
  })));
}
function PhoneShell({
  children,
  dark = false,
  bg
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 844,
      flexShrink: 0,
      borderRadius: 46,
      padding: 0,
      overflow: 'hidden',
      position: 'relative',
      background: bg || 'var(--bg-base)',
      border: '10px solid #120B19',
      boxShadow: 'var(--shadow-xl)',
      display: 'flex',
      flexDirection: 'column'
    },
    className: dark ? 'dark' : ''
  }, /*#__PURE__*/React.createElement(StatusBar, {
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column',
      position: 'relative'
    }
  }, children));
}

/* Bottom tab bar used by Discover & Chat kits */
function TabBar({
  active,
  onChange
}) {
  const tabs = [{
    id: 'discover',
    icon: 'flame',
    label: 'Jelajah'
  }, {
    id: 'rooms',
    icon: 'users',
    label: 'Ruang'
  }, {
    id: 'chat',
    icon: 'message-circle',
    label: 'Chat'
  }, {
    id: 'profile',
    icon: 'user',
    label: 'Profil'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      justifyContent: 'space-around',
      alignItems: 'center',
      padding: '10px 12px 26px',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, tabs.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => onChange && onChange(t.id),
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '4px 12px',
        color: on ? 'var(--brand-primary)' : 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": t.icon,
      style: {
        width: 24,
        height: 24
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontSize: 10.5,
        fontWeight: on ? 800 : 600
      }
    }, t.label));
  }));
}

/* Re-render lucide icons after every paint */
function useLucide() {
  useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
}
Object.assign(window, {
  Logomark,
  PhoneShell,
  StatusBar,
  TabBar,
  useLucide
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/_shared/shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/chat/app.jsx
try { (() => {
/* SEFREKUENSI — Chat & Rooms app (clickthrough) */
function ChatApp() {
  const [tab, setTab] = useState('chat'); // chat | rooms
  const [convo, setConvo] = useState(null);
  const [room, setRoom] = useState(null);
  useLucide();
  let body;
  if (tab === 'chat') {
    body = convo ? /*#__PURE__*/React.createElement(ChatThreadScreen, {
      convo: convo,
      onBack: () => setConvo(null)
    }) : /*#__PURE__*/React.createElement(ChatListScreen, {
      onOpen: setConvo
    });
  } else {
    body = room ? /*#__PURE__*/React.createElement(RoomThreadScreen, {
      room: room,
      onBack: () => setRoom(null)
    }) : /*#__PURE__*/React.createElement(RoomsScreen, {
      onOpen: setRoom
    });
  }
  const inThread = tab === 'chat' && convo || tab === 'rooms' && room;
  return /*#__PURE__*/React.createElement(PhoneShell, null, body, !inThread && /*#__PURE__*/React.createElement(TabBar, {
    active: tab === 'rooms' ? 'rooms' : 'chat',
    onChange: t => {
      if (t === 'rooms') {
        setTab('rooms');
      } else if (t === 'chat') {
        setTab('chat');
      } else {
        setTab('chat');
      }
    }
  }));
}
function Stage() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 40,
      background: 'var(--bg-subtle)'
    }
  }, /*#__PURE__*/React.createElement(ChatApp, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(Stage, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/chat/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/chat/rooms.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* SEFREKUENSI — Community Rooms screens */
const NSr = window.SEFREKUENSIDesignSystem_629d2b;
const {
  RoomCard: RC,
  Avatar: Av,
  IconButton: IB,
  Badge: Bd
} = NSr;
const RIcon = (n, s = 20, style = {}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    ...style
  }
});
const rav = n => `https://i.pravatar.cc/160?img=${n}`;
const ROOMS = [{
  id: 'senja',
  name: 'Ruang Senja & Kopi',
  topic: 'Santai',
  members: 128,
  live: true,
  tags: ['Kopi', 'Indie', 'Curhat'],
  cover: 'var(--gradient-aurora)',
  avatars: [rav(5), rav(12), rav(9), rav(20)]
}, {
  id: 'gig',
  name: 'Anak Gig Jakarta',
  topic: 'Musik',
  members: 342,
  live: true,
  tags: ['Indie', 'Vinyl', 'Konser'],
  cover: 'linear-gradient(120deg,#7C3AED,#3A86FF)',
  avatars: [rav(15), rav(31), rav(8)]
}, {
  id: 'naik',
  name: 'Yuk Naik Gunung',
  topic: 'Outdoor',
  members: 96,
  live: false,
  tags: ['Mendaki', 'Camping'],
  cover: 'linear-gradient(120deg,#12E0A0,#7C3AED)',
  avatars: [rav(45), rav(33), rav(60), rav(22)]
}, {
  id: 'nugas',
  name: 'Nugas Bareng',
  topic: 'Produktif',
  members: 211,
  live: true,
  tags: ['Belajar', 'Fokus'],
  cover: 'linear-gradient(120deg,#FF7A4D,#FF2E7E)',
  avatars: [rav(11), rav(48), rav(25)]
}];
function RoomsScreen({
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      padding: '6px 20px 12px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 28,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)',
      margin: 0
    }
  }, "Ruang"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 13.5,
      color: 'var(--text-muted)',
      margin: '2px 0 0'
    }
  }, "Ngobrol bareng yang satu frekuensi.")), /*#__PURE__*/React.createElement(IB, {
    variant: "primary",
    size: "md",
    label: "Buat ruang"
  }, RIcon('plus', 22))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px 20px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, ROOMS.map(r => /*#__PURE__*/React.createElement(RC, _extends({
    key: r.id
  }, r, {
    width: "100%",
    onClick: () => onOpen(r)
  })))));
}
const ROOM_MSGS = [{
  who: 'Rara',
  img: rav(5),
  text: 'Pagi semua! Ada yang udah cobain roastery baru di Senopati?',
  time: '08:12'
}, {
  who: 'Dimas',
  img: rav(12),
  text: 'Belum, tapi penasaran. Filter atau espresso based?',
  time: '08:14'
}, {
  who: 'me',
  text: 'Filternya enak banget kemarin nyobain, fruity gitu 🍓',
  time: '08:15'
}, {
  who: 'Nadia',
  img: rav(9),
  text: 'Wih jadi pengen. Weekend kesana yuk rame-rame?',
  time: '08:17'
}];
function RoomThreadScreen({
  room,
  onBack
}) {
  const [text, setText] = useState('');
  const [msgs, setMsgs] = useState(ROOM_MSGS);
  const scroller = useRef(null);
  useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [msgs]);
  const send = () => {
    if (!text.trim()) return;
    setMsgs(m => [...m, {
      who: 'me',
      text: text.trim(),
      time: '08:18'
    }]);
    setText('');
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '6px 14px 12px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      width: 38,
      height: 38,
      borderRadius: 999,
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      color: 'var(--text-strong)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, RIcon('arrow-left', 22)), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      background: room.cover,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 16,
      color: 'var(--text-strong)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, room.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      color: 'var(--text-muted)',
      fontWeight: 600
    }
  }, room.live && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      color: 'var(--mint-600)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: 'var(--mint-500)'
    }
  }), " live"), "\xB7 ", room.members, " anggota")), /*#__PURE__*/React.createElement("button", {
    style: {
      width: 38,
      height: 38,
      borderRadius: 999,
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      color: 'var(--text-strong)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, RIcon('users', 20))), /*#__PURE__*/React.createElement("div", {
    ref: scroller,
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      background: 'var(--bg-subtle)'
    }
  }, msgs.map((m, i) => m.who === 'me' ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      alignSelf: 'flex-end',
      maxWidth: '80%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 14px',
      background: 'var(--gradient-frekuensi)',
      color: '#fff',
      borderRadius: 18,
      borderBottomRightRadius: 5,
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      fontWeight: 500,
      lineHeight: 1.4,
      boxShadow: 'var(--glow-pink)'
    }
  }, m.text), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)',
      marginTop: 3
    }
  }, m.time)) : /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 8,
      alignSelf: 'flex-start',
      maxWidth: '82%'
    }
  }, /*#__PURE__*/React.createElement(Av, {
    name: m.who,
    src: m.img,
    size: "sm",
    style: {
      marginTop: 16
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 11.5,
      fontWeight: 700,
      color: 'var(--brand-secondary)',
      margin: '0 0 3px 4px'
    }
  }, m.who), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 14px',
      background: 'var(--surface-card)',
      color: 'var(--text-strong)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 18,
      borderBottomLeftRadius: 5,
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      fontWeight: 500,
      lineHeight: 1.4
    }
  }, m.text), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      color: 'var(--text-muted)',
      margin: '3px 0 0 4px'
    }
  }, m.time))))), /*#__PURE__*/React.createElement(Composer, {
    value: text,
    onChange: setText,
    onSend: send
  }));
}
Object.assign(window, {
  RoomsScreen,
  RoomThreadScreen,
  ROOMS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/chat/rooms.jsx", error: String((e && e.message) || e) }); }

// ui_kits/chat/screens.jsx
try { (() => {
/* SEFREKUENSI — Chat & Community Rooms screens */
const NSc = window.SEFREKUENSIDesignSystem_629d2b;
const {
  ChatBubble,
  Avatar,
  Badge,
  RoomCard,
  IconButton,
  Input,
  FrequencyMeter,
  Button
} = NSc;
const CIcon = (n, s = 20, style = {}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    ...style
  }
});
const av = n => `https://i.pravatar.cc/160?img=${n}`;
const CONVOS = [{
  id: 'rara',
  name: 'Rara',
  img: av(5),
  last: 'Belum nih, ajarin dong 🙏',
  time: '19:06',
  unread: 2,
  online: true,
  match: 94
}, {
  id: 'dimas',
  name: 'Dimas',
  img: av(12),
  last: 'Gig sabtu ini yuk?',
  time: '17:22',
  unread: 0,
  online: false,
  match: 81
}, {
  id: 'nadia',
  name: 'Nadia',
  img: av(9),
  last: 'Kamu: sip, ku bawain bibitnya',
  time: 'Kemarin',
  unread: 0,
  online: true,
  match: 88
}];
const NEW_MATCHES = [{
  name: 'Bagas',
  img: av(15)
}, {
  name: 'Sasa',
  img: av(31)
}, {
  name: 'Yoga',
  img: av(8)
}, {
  name: 'Mira',
  img: av(45)
}];
function SectionHead({
  children,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 4px 10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, children), action);
}

/* ---- Chat list ---- */
function ChatListScreen({
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 20px 8px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 28,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)',
      margin: '0 0 14px'
    }
  }, "Chat"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '0 14px',
      height: 44,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border-subtle)'
    }
  }, CIcon('search', 18, {
    color: 'var(--text-muted)'
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--text-muted)'
    }
  }, "Cari obrolan..."))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '8px 20px 16px'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, null, "Frekuensi baru"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      overflowX: 'auto',
      paddingBottom: 16,
      marginBottom: 8
    }
  }, NEW_MATCHES.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.name,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: m.name,
    src: m.img,
    size: "lg",
    ring: true
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--text-body)'
    }
  }, m.name)))), /*#__PURE__*/React.createElement(SectionHead, null, "Pesan"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, CONVOS.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    onClick: () => onOpen(c),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 13,
      padding: '12px 6px',
      background: 'none',
      border: 'none',
      borderBottom: '1px solid var(--border-subtle)',
      cursor: 'pointer',
      textAlign: 'left',
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: c.name,
    src: c.img,
    size: "lg",
    status: c.online ? 'online' : undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 16,
      color: 'var(--text-strong)'
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      fontWeight: 700,
      color: 'var(--brand-primary)'
    }
  }, c.match, "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 13.5,
      color: c.unread ? 'var(--text-body)' : 'var(--text-muted)',
      fontWeight: c.unread ? 600 : 400,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      marginTop: 2
    }
  }, c.last)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-muted)'
    }
  }, c.time), c.unread > 0 && /*#__PURE__*/React.createElement(Badge, {
    variant: "gradient",
    size: "sm"
  }, c.unread)))))));
}

/* ---- 1:1 chat thread ---- */
function ChatThreadScreen({
  convo,
  onBack
}) {
  const [msgs, setMsgs] = useState([{
    side: 'received',
    text: 'Halo! Liat kita sama-sama suka kopi 👀',
    time: '19:04'
  }, {
    side: 'sent',
    text: 'Wkwk iya! Udah cobain manual brew belum?',
    time: '19:05',
    read: true
  }, {
    side: 'received',
    text: 'Belum nih, ajarin dong 🙏',
    time: '19:06'
  }]);
  const [text, setText] = useState('');
  const scroller = useRef(null);
  useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [msgs]);
  const send = () => {
    if (!text.trim()) return;
    setMsgs(m => [...m, {
      side: 'sent',
      text: text.trim(),
      time: '19:07',
      read: false
    }]);
    setText('');
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '6px 16px 12px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      width: 38,
      height: 38,
      borderRadius: 999,
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      color: 'var(--text-strong)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, CIcon('arrow-left', 22)), /*#__PURE__*/React.createElement(Avatar, {
    name: convo.name,
    src: convo.img,
    size: "md",
    status: convo.online ? 'online' : undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 16,
      color: 'var(--text-strong)'
    }
  }, convo.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      color: 'var(--mint-600)',
      fontWeight: 600
    }
  }, convo.online ? 'Online' : 'Aktif 2j lalu')), /*#__PURE__*/React.createElement(Badge, {
    variant: "soft",
    size: "sm",
    dot: true
  }, convo.match, "% cocok")), /*#__PURE__*/React.createElement("div", {
    ref: scroller,
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      background: 'var(--bg-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: 'center',
      fontFamily: 'var(--font-mono)',
      fontSize: 10.5,
      color: 'var(--text-muted)',
      background: 'var(--surface-card)',
      padding: '4px 12px',
      borderRadius: 999,
      marginBottom: 4
    }
  }, "Kalian cocok hari ini \xB7 ", convo.match, "%"), msgs.map((m, i) => /*#__PURE__*/React.createElement(ChatBubble, {
    key: i,
    side: m.side,
    time: m.time,
    read: m.read
  }, m.text))), /*#__PURE__*/React.createElement(Composer, {
    value: text,
    onChange: setText,
    onSend: send
  }));
}

/* ---- Composer ---- */
function Composer({
  value,
  onChange,
  onSend
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '12px 16px 26px',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      width: 42,
      height: 42,
      flexShrink: 0,
      borderRadius: 999,
      border: 'none',
      background: 'var(--surface-sunken)',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, CIcon('plus', 22)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '0 8px 0 16px',
      height: 46,
      background: 'var(--surface-sunken)',
      borderRadius: 999,
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: e => onChange(e.target.value),
    onKeyDown: e => e.key === 'Enter' && onSend(),
    placeholder: "Tulis pesan...",
    style: {
      flex: 1,
      border: 'none',
      background: 'none',
      outline: 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      color: 'var(--text-strong)'
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 999,
      border: 'none',
      background: 'none',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, CIcon('smile', 20))), /*#__PURE__*/React.createElement(IconButton, {
    variant: "primary",
    size: "md",
    label: "Kirim",
    onClick: onSend
  }, CIcon('send', 19)));
}
Object.assign(window, {
  ChatListScreen,
  ChatThreadScreen,
  Composer,
  SectionHead,
  CONVOS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/chat/screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/discover/app.jsx
try { (() => {
/* SEFREKUENSI — Discover app (clickthrough) */
function DiscoverApp() {
  const [tab, setTab] = useState('discover');
  const [match, setMatch] = useState(null);
  useLucide();
  const body = {
    discover: /*#__PURE__*/React.createElement(DiscoverScreen, {
      onMatch: setMatch
    }),
    rooms: /*#__PURE__*/React.createElement(Placeholder, {
      icon: "users",
      title: "Ruang komunitas",
      sub: "Lihat kit Chat & Ruang untuk pengalaman penuh."
    }),
    chat: /*#__PURE__*/React.createElement(Placeholder, {
      icon: "message-circle",
      title: "Obrolan kamu",
      sub: "Lihat kit Chat & Ruang untuk pengalaman penuh."
    }),
    profile: /*#__PURE__*/React.createElement(ProfileScreen, null)
  }[tab];
  return /*#__PURE__*/React.createElement(PhoneShell, null, body, /*#__PURE__*/React.createElement(TabBar, {
    active: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement(MatchModal, {
    profile: match,
    onClose: () => setMatch(null),
    onChat: () => setMatch(null)
  }));
}
function Stage() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 40,
      background: 'var(--bg-subtle)'
    }
  }, /*#__PURE__*/React.createElement(DiscoverApp, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(Stage, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/discover/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/discover/screens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* SEFREKUENSI — Discover (swipe / friend search) screens */
const NSd = window.SEFREKUENSIDesignSystem_629d2b;
const {
  ProfileCard,
  IconButton,
  Tabs,
  FrequencyMeter,
  Avatar,
  Badge,
  Button
} = NSd;
const DIcon = (n, s = 20, style = {}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    ...style
  }
});
const PROFILES = [{
  name: 'Rara',
  age: 23,
  distance: 3,
  online: true,
  verified: true,
  match: 94,
  photo: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=700&q=80',
  bio: 'Suka senja, playlist indie & manual brew. Cari teman ngopi.',
  interests: [{
    label: 'Kopi',
    shared: true
  }, {
    label: 'Indie film',
    shared: true
  }, {
    label: 'Mendaki'
  }, {
    label: 'Fotografi'
  }]
}, {
  name: 'Dimas',
  age: 25,
  distance: 5,
  online: false,
  verified: false,
  match: 81,
  photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=700&q=80',
  bio: 'Anak band, kerjaan pagi. Nyari yang bisa diajak nonton gig.',
  interests: [{
    label: 'Vinyl',
    shared: true
  }, {
    label: 'Indie film',
    shared: true
  }, {
    label: 'Gaming'
  }]
}, {
  name: 'Nadia',
  age: 22,
  distance: 2,
  online: true,
  verified: true,
  match: 88,
  photo: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=700&q=80',
  bio: 'Plant parent & tukang masak. Weekend = thrifting.',
  interests: [{
    label: 'Masak',
    shared: true
  }, {
    label: 'Thrifting'
  }, {
    label: 'Plant parent'
  }]
}, {
  name: 'Bagas',
  age: 24,
  distance: 8,
  online: true,
  verified: false,
  match: 76,
  photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=700&q=80',
  bio: 'Lari pagi, baca buku, sesekali stand-up. Yuk ngobrol random.',
  interests: [{
    label: 'Lari',
    shared: true
  }, {
    label: 'Buku',
    shared: true
  }, {
    label: 'Stand-up'
  }]
}];
function SwipeDeck({
  onMatch
}) {
  const [idx, setIdx] = useState(0);
  const [drag, setDrag] = useState({
    x: 0,
    y: 0,
    active: false
  });
  const startRef = useRef(null);
  const stamp = drag.x > 60 ? 'like' : drag.x < -60 ? 'nope' : null;
  const release = liked => {
    const p = PROFILES[idx];
    setDrag({
      x: 0,
      y: 0,
      active: false
    });
    setIdx(i => (i + 1) % PROFILES.length);
    if (liked && p && p.match >= 85) setTimeout(() => onMatch(p), 220);
  };
  const onDown = e => {
    startRef.current = {
      x: e.clientX,
      y: e.clientY
    };
    setDrag(d => ({
      ...d,
      active: true
    }));
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onMove = e => {
    if (!startRef.current) return;
    setDrag({
      x: e.clientX - startRef.current.x,
      y: e.clientY - startRef.current.y,
      active: true
    });
  };
  const onUp = () => {
    if (!startRef.current) return;
    const x = drag.x;
    startRef.current = null;
    if (x > 90) release(true);else if (x < -90) release(false);else setDrag({
      x: 0,
      y: 0,
      active: false
    });
  };
  const button = liked => {
    setDrag({
      x: liked ? 180 : -180,
      y: 0,
      active: false
    });
    setTimeout(() => release(liked), 180);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: 'relative',
      margin: '4px 20px 0'
    }
  }, [2, 1, 0].map(off => {
    const i = (idx + off) % PROFILES.length;
    const p = PROFILES[i];
    const top = off === 0;
    const scale = 1 - off * 0.04;
    const ty = off * 12;
    return /*#__PURE__*/React.createElement("div", {
      key: i + '-' + off,
      onPointerDown: top ? onDown : undefined,
      onPointerMove: top ? onMove : undefined,
      onPointerUp: top ? onUp : undefined,
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        display: 'flex',
        justifyContent: 'center',
        transform: top ? `translate(${drag.x}px, ${drag.y * 0.3}px) rotate(${drag.x * 0.04}deg)` : `translateY(${ty}px) scale(${scale})`,
        transition: drag.active && top ? 'none' : 'transform var(--dur-slow) var(--ease-out)',
        zIndex: 10 - off,
        touchAction: 'none',
        cursor: top ? 'grab' : 'default'
      }
    }, /*#__PURE__*/React.createElement(ProfileCard, _extends({}, p, {
      stamp: top ? stamp : null,
      width: 330,
      height: 464
    })));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 18,
      padding: '18px 0 14px'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "soft",
    size: "lg",
    label: "Lewati",
    onClick: () => button(false),
    style: {
      color: 'var(--red-500)'
    }
  }, DIcon('x', 26)), /*#__PURE__*/React.createElement(IconButton, {
    variant: "soft",
    size: "md",
    label: "Super suka",
    onClick: () => button(true),
    style: {
      color: 'var(--brand-secondary)'
    }
  }, DIcon('star', 20)), /*#__PURE__*/React.createElement(IconButton, {
    variant: "primary",
    size: "lg",
    label: "Suka",
    onClick: () => button(true)
  }, DIcon('heart', 26)), /*#__PURE__*/React.createElement(IconButton, {
    variant: "soft",
    size: "md",
    label: "Sapa",
    onClick: () => button(true),
    style: {
      color: 'var(--coral-500)'
    }
  }, DIcon('hand', 20))));
}
function DiscoverScreen({
  onMatch
}) {
  const [tab, setTab] = useState('foryou');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '6px 20px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(Logomark, {
    size: 32
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 20,
      color: 'var(--text-strong)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand-primary)'
    }
  }, "se"), "frekuensi")), /*#__PURE__*/React.createElement("button", {
    style: {
      width: 42,
      height: 42,
      borderRadius: 999,
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      cursor: 'pointer',
      color: 'var(--text-strong)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, DIcon('sliders-horizontal', 20))), /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      display: 'flex',
      justifyContent: 'center',
      paddingBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    size: "sm",
    items: [{
      id: 'foryou',
      label: 'Untukmu'
    }, {
      id: 'near',
      label: 'Terdekat',
      icon: DIcon('map-pin', 15)
    }, {
      id: 'online',
      label: 'Online'
    }]
  })), /*#__PURE__*/React.createElement(SwipeDeck, {
    onMatch: onMatch
  }));
}
function MatchModal({
  profile,
  onClose,
  onChat
}) {
  if (!profile) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 50,
      background: 'rgba(18,11,25,0.6)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-xl)',
      padding: 26,
      textAlign: 'center',
      boxShadow: 'var(--shadow-xl)',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 900,
      fontSize: 32,
      letterSpacing: '-0.02em',
      lineHeight: 1.05,
      margin: '4px 0 4px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sf-gradient-text"
  }, "Satu frekuensi!")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      color: 'var(--text-muted)',
      margin: '0 0 18px'
    }
  }, "Kamu & ", profile.name, " saling suka."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: -10,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Kamu",
    src: "https://i.pravatar.cc/160?img=33",
    size: "xl",
    ring: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '0 -8px',
      zIndex: 2,
      width: 40,
      height: 40,
      borderRadius: 999,
      background: 'var(--gradient-frekuensi)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: 'var(--glow-pink)'
    }
  }, DIcon('heart', 20, {
    color: '#fff'
  })), /*#__PURE__*/React.createElement(Avatar, {
    name: profile.name,
    src: profile.photo,
    size: "xl",
    ring: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(FrequencyMeter, {
    value: profile.match,
    size: "sm",
    label: "Frekuensi cocok"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    full: true,
    onClick: onChat,
    iconLeft: DIcon('message-circle', 18)
  }, "Kirim pesan"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "md",
    full: true,
    onClick: onClose
  }, "Lanjut jelajah"))));
}
function ProfileScreen() {
  const tags = ['Kopi', 'Indie film', 'Mendaki', 'Fotografi', 'Vinyl'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 150,
      background: 'var(--gradient-aurora)',
      position: 'relative'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 22px 22px',
      marginTop: -52
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Kamu",
    src: "https://i.pravatar.cc/200?img=33",
    size: "xl",
    ring: true,
    style: {
      width: 104,
      height: 104
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      marginBottom: 8,
      padding: '9px 18px',
      borderRadius: 999,
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: 13.5,
      color: 'var(--text-strong)',
      cursor: 'pointer',
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center'
    }
  }, DIcon('pencil', 15), " Edit")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 26,
      color: 'var(--text-strong)'
    }
  }, "Kamu, 24"), DIcon('badge-check', 22, {
    color: 'var(--mint-600)'
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      color: 'var(--text-body)',
      lineHeight: 1.5,
      margin: '8px 0 18px'
    }
  }, "Pencari senja & teman ngobrol random. Kalau frekuensi kita sama, sapa aja \uD83D\uDC4B"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(FrequencyMeter, {
    value: 88,
    size: "md",
    label: "Kekuatan profil"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      marginBottom: 10
    }
  }, "Frekuensi kamu"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, tags.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    style: {
      padding: '8px 14px',
      borderRadius: 999,
      background: 'var(--brand-tint)',
      color: 'var(--brand-primary)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 13.5
    }
  }, t)))));
}
function Placeholder({
  icon,
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 14,
      padding: 32,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 72,
      height: 72,
      borderRadius: 22,
      background: 'var(--brand-tint)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--brand-primary)'
    }
  }, DIcon(icon, 32)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 20,
      color: 'var(--text-strong)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--text-muted)',
      margin: 0,
      maxWidth: 240,
      lineHeight: 1.5
    }
  }, sub));
}
Object.assign(window, {
  SwipeDeck,
  DiscoverScreen,
  MatchModal,
  ProfileScreen,
  Placeholder,
  PROFILES
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/discover/screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/onboarding/app.jsx
try { (() => {
/* SEFREKUENSI — Onboarding app (clickthrough) */
function OnboardingApp() {
  const [step, setStep] = useState('welcome');
  useLucide();
  const dark = false;
  const screen = {
    welcome: /*#__PURE__*/React.createElement(WelcomeScreen, {
      onStart: () => setStep('interests'),
      onLogin: () => setStep('login')
    }),
    login: /*#__PURE__*/React.createElement(LoginScreen, {
      onBack: () => setStep('welcome'),
      onContinue: () => setStep('interests')
    }),
    interests: /*#__PURE__*/React.createElement(InterestsScreen, {
      onBack: () => setStep('welcome'),
      onDone: () => setStep('ready')
    }),
    ready: /*#__PURE__*/React.createElement(ReadyScreen, {
      onEnter: () => setStep('welcome')
    })
  }[step];
  const onWelcome = step === 'welcome';
  return /*#__PURE__*/React.createElement(PhoneShell, {
    dark: dark,
    bg: onWelcome ? 'var(--gradient-aurora)' : 'var(--bg-base)'
  }, screen);
}
function Stage() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 40,
      background: 'var(--bg-subtle)'
    }
  }, /*#__PURE__*/React.createElement(OnboardingApp, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(Stage, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/onboarding/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/onboarding/screens.jsx
try { (() => {
/* SEFREKUENSI — Onboarding screens */
const NS = window.SEFREKUENSIDesignSystem_629d2b;
const {
  Button,
  Input,
  InterestTag,
  FrequencyMeter
} = NS;
const Icon = (n, s = 20, style = {}) => /*#__PURE__*/React.createElement("i", {
  "data-lucide": n,
  style: {
    width: s,
    height: s,
    ...style
  }
});

/* 1 — Welcome */
function WelcomeScreen({
  onStart,
  onLogin
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: 'relative',
      background: 'var(--gradient-aurora)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(120% 80% at 50% 0%, rgba(255,255,255,0.18), transparent 60%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 70,
      left: 24,
      transform: 'rotate(-8deg)',
      padding: '8px 14px',
      borderRadius: 999,
      background: 'rgba(255,255,255,0.18)',
      backdropFilter: 'blur(8px)',
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      fontFamily: 'var(--font-sans)'
    }
  }, "\u2615 Kopi"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 130,
      right: 28,
      transform: 'rotate(7deg)',
      padding: '8px 14px',
      borderRadius: 999,
      background: 'rgba(255,255,255,0.18)',
      backdropFilter: 'blur(8px)',
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      fontFamily: 'var(--font-sans)'
    }
  }, "\uD83C\uDFA7 Indie"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 196,
      left: 40,
      transform: 'rotate(5deg)',
      padding: '8px 14px',
      borderRadius: 999,
      background: 'rgba(255,255,255,0.18)',
      backdropFilter: 'blur(8px)',
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      fontFamily: 'var(--font-sans)'
    }
  }, "\u26F0\uFE0F Mendaki"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'flex-end',
      padding: '0 28px 40px',
      position: 'relative',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 'auto',
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Logomark, {
    size: 76
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 40,
      lineHeight: 1.02,
      letterSpacing: '-0.03em',
      color: '#fff',
      textAlign: 'center',
      margin: '0 0 14px'
    }
  }, "Cari yang", /*#__PURE__*/React.createElement("br", null), "satu frekuensi"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 16,
      fontWeight: 500,
      color: 'rgba(255,255,255,0.88)',
      textAlign: 'center',
      lineHeight: 1.5,
      margin: '0 0 28px',
      maxWidth: 300
    }
  }, "Ketemu orang & teman baru lewat hobi, pola pikir, dan hal yang sama-sama kalian suka."), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    full: true,
    onClick: onStart,
    style: {
      background: '#fff',
      color: 'var(--pink-600)',
      boxShadow: '0 10px 30px rgba(0,0,0,0.18)'
    },
    iconRight: Icon('arrow-right', 18)
  }, "Mulai sekarang"), /*#__PURE__*/React.createElement("button", {
    onClick: onLogin,
    style: {
      background: 'none',
      border: 'none',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: 14.5,
      cursor: 'pointer',
      padding: 8
    }
  }, "Sudah punya akun? ", /*#__PURE__*/React.createElement("span", {
    style: {
      textDecoration: 'underline'
    }
  }, "Masuk")))));
}

/* 2 — Login */
function LoginScreen({
  onBack,
  onContinue
}) {
  const [phone, setPhone] = useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      padding: '8px 24px 32px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      alignSelf: 'flex-start',
      width: 40,
      height: 40,
      borderRadius: 999,
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--text-strong)'
    }
  }, Icon('arrow-left', 20)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 30,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)',
      margin: '0 0 8px'
    }
  }, "Masuk ke frekuensi"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      color: 'var(--text-muted)',
      margin: '0 0 28px',
      lineHeight: 1.5
    }
  }, "Kami kirim kode verifikasi ke nomor kamu.")), /*#__PURE__*/React.createElement(Input, {
    label: "Nomor HP",
    placeholder: "+62 812 3456 7890",
    value: phone,
    onChange: e => setPhone(e.target.value),
    iconLeft: Icon('phone', 18)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    full: true,
    onClick: onContinue,
    iconRight: Icon('arrow-right', 18)
  }, "Kirim kode")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      margin: '28px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      letterSpacing: '0.08em'
    }
  }, "ATAU"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--border-subtle)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    full: true,
    onClick: onContinue,
    iconLeft: Icon('mail', 18)
  }, "Lanjut dengan Email"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    full: true,
    onClick: onContinue,
    iconLeft: Icon('apple', 18)
  }, "Lanjut dengan Apple")), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 'auto',
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      color: 'var(--text-muted)',
      textAlign: 'center',
      lineHeight: 1.5
    }
  }, "Dengan lanjut, kamu setuju sama ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-body)'
    }
  }, "Syarat"), " & ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-body)'
    }
  }, "Privasi"), " kami."));
}

/* 3 — Interests */
const INTERESTS = [{
  l: 'Kopi',
  i: 'coffee'
}, {
  l: 'Indie film',
  i: 'clapperboard'
}, {
  l: 'Mendaki',
  i: 'mountain'
}, {
  l: 'K-pop',
  i: 'music'
}, {
  l: 'Gaming',
  i: 'gamepad-2'
}, {
  l: 'Fotografi',
  i: 'camera'
}, {
  l: 'Masak',
  i: 'utensils'
}, {
  l: 'Lari',
  i: 'footprints'
}, {
  l: 'Buku',
  i: 'book-open'
}, {
  l: 'Anime',
  i: 'sparkles'
}, {
  l: 'Nugas bareng',
  i: 'graduation-cap'
}, {
  l: 'Thrifting',
  i: 'shirt'
}, {
  l: 'Plant parent',
  i: 'leaf'
}, {
  l: 'Vinyl',
  i: 'disc-3'
}, {
  l: 'Stand-up',
  i: 'mic'
}, {
  l: 'Travelling',
  i: 'plane'
}];
function InterestsScreen({
  onBack,
  onDone
}) {
  const [sel, setSel] = useState({
    Kopi: true,
    'Indie film': true,
    Mendaki: true
  });
  const count = Object.values(sel).filter(Boolean).length;
  const toggle = l => setSel(s => ({
    ...s,
    [l]: !s[l]
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 24px 16px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      width: 40,
      height: 40,
      borderRadius: 999,
      border: '1px solid var(--border-default)',
      background: 'var(--surface-card)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--text-strong)',
      marginBottom: 18
    }
  }, Icon('arrow-left', 20)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: 'var(--brand-primary)',
      marginBottom: 8
    }
  }, "// Langkah 2 dari 3"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 28,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)',
      margin: '0 0 6px'
    }
  }, "Apa frekuensi kamu?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      color: 'var(--text-muted)',
      margin: 0
    }
  }, "Pilih min. 3 hal yang kamu suka. Kami cariin yang nyambung.")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      padding: '4px 24px 16px',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 10,
      alignContent: 'flex-start'
    }
  }, INTERESTS.map(it => /*#__PURE__*/React.createElement(InterestTag, {
    key: it.l,
    icon: Icon(it.i, 16),
    selected: !!sel[it.l],
    onClick: () => toggle(it.l)
  }, it.l))), /*#__PURE__*/React.createElement("div", {
    style: {
      flexShrink: 0,
      padding: '16px 24px 30px',
      background: 'var(--surface-card)',
      borderTop: '1px solid var(--border-subtle)',
      boxShadow: '0 -8px 24px rgba(46,36,54,0.06)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    full: true,
    disabled: count < 3,
    onClick: onDone,
    iconRight: Icon('arrow-right', 18)
  }, count < 3 ? `Pilih ${3 - count} lagi` : `Lanjut · ${count} dipilih`)));
}

/* 4 — Ready */
function ReadyScreen({
  onEnter
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '0 28px',
      textAlign: 'center',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 96,
      height: 96,
      borderRadius: 28,
      background: 'var(--gradient-frekuensi)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: 'var(--glow-brand)'
    }
  }, Icon('check', 48, {
    color: '#fff'
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 30,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)',
      margin: '0 0 8px'
    }
  }, "Frekuensi kamu siap!"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      color: 'var(--text-muted)',
      margin: 0,
      lineHeight: 1.5
    }
  }, "Kami nemu 28 orang yang satu gelombang sama kamu di sekitar sini.")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 280
    }
  }, /*#__PURE__*/React.createElement(FrequencyMeter, {
    value: 88,
    size: "md",
    label: "Kekuatan profil"
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    full: true,
    onClick: onEnter,
    iconRight: Icon('arrow-right', 18),
    style: {
      maxWidth: 280
    }
  }, "Mulai jelajah"));
}
Object.assign(window, {
  WelcomeScreen,
  LoginScreen,
  InterestsScreen,
  ReadyScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/onboarding/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.InterestTag = __ds_scope.InterestTag;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.ChatBubble = __ds_scope.ChatBubble;

__ds_ns.FrequencyMeter = __ds_scope.FrequencyMeter;

__ds_ns.ProfileCard = __ds_scope.ProfileCard;

__ds_ns.RoomCard = __ds_scope.RoomCard;

})();
