# SEFREKUENSI — Design System

> **SEFREKUENSI** ("se-frekuensi" / *same frequency*) is a dating & friend-matching
> platform for Indonesian Gen Z and Millennials. Instead of matching on looks alone, it
> pairs people on **shared hobbies, mindset and interests** — when two people are on the
> same wavelength, they "tune in." Beyond 1:1 matching, SEFREKUENSI hosts **ruang**
> (community chat rooms) where people gather around a shared frequency.

The product is **modern, clean, but warm and playful**. Three core surfaces:
**Discover** (swipe/match — *dashboard pencarian teman*), **Chat & Rooms**, and **Onboarding**.

### Sources
This system was created **from scratch** from a written brief — there was no existing
codebase, Figma file, or brand kit. Direction confirmed with the user:
- Color: **neon-modern, high-contrast** (hot pink → electric violet), grounded in warm neutrals.
- Vibe: **warm & cozy**, geometric-rounded type, medium radius, **light + dark**.
- Surfaces: Onboarding, Discover, Chat & Community Rooms.
- Stack note from brief: built to pair with **Tailwind CSS** (token values below map cleanly to a Tailwind theme).

If you have newer brand assets (a real logo, brand photography, font licenses), share them
and we'll swap them in — see **Caveats** at the bottom.

---

## Brand concept

The name is the system. **Frequency / waveform / tuning** is the central metaphor:
- The **logomark** is an equalizer that rises to a single peak — two signals tuning to one.
- The signature **FrequencyMeter** shows compatibility as an equalizer "tuning up" to the match %.
- Eyebrow labels read like a **frequency readout** in mono (`// FREKUENSI COCOK`, `94% · 432Hz`).
- A match is **"Satu frekuensi!"**; the primary verb is **"Tune in"**.

---

## CONTENT FUNDAMENTALS

**Language:** Bahasa Indonesia, casual/colloquial (Jakarta Gen-Z register), with light
English loanwords that this audience uses naturally ("match", "online", "vibe", "gig",
"thrifting"). Never stiff or formal Indonesian.

**Voice:** A warm, fun friend who's hyping you up — not a corporation. Encouraging,
playful, a little cheeky, never cringe or salesy.

**Person:** Address the user as **"kamu"** (informal you); the app refers to itself as
**"kami"** sparingly. Never "Anda" (too formal).

**Casing:** Sentence case everywhere — headlines, buttons, labels. The only all-caps is the
**mono eyebrow/readout** motif (`// LANGKAH 2 DARI 3`) and short status stamps (`LIVE`, `COCOK`).

**Tone examples (use these as a yardstick):**
- Hero: *"Cari yang satu frekuensi"* / *"Ketemu orang & teman baru lewat hobi, pola pikir, dan hal yang sama-sama kalian suka."*
- Match: *"Satu frekuensi!"* → *"Kamu & Rara saling suka."*
- Onboarding CTA: *"Pilih min. 3 hal yang kamu suka. Kami cariin yang nyambung."*
- Empty/disabled CTA: *"Pilih 2 lagi"* → *"Lanjut · 5 dipilih"*
- Microcopy: *"Aman & nyaman. Kamu yang pegang kendali."*

**Emoji:** Used **sparingly and naturally**, the way this audience texts — 0–1 per message,
in chat bubbles, floating interest chips, and the occasional friendly line (👀 🙏 👋 🍓).
Never in headlines, never as a substitute for an icon, never decorative clusters.

**Numbers/units:** Compatibility as `%`; distance in `km`; the frequency flavor uses `Hz`.
Indonesian number formatting (`1.234`).

**Do:** keep it short, human, warm. **Don't:** corporate hedging, ALL-CAPS shouting,
exclamation overload, dark-pattern urgency.

---

## VISUAL FOUNDATIONS

### Color
- **Signature duo:** *Getar* (pink `#FF2E7E`) → *Frekuensi* (violet `#7C3AED`), almost always
  expressed as the **`--gradient-frekuensi`** (120° pink→violet). This gradient is the brand —
  it fills the primary button, active tab, selected chip, FrequencyMeter bars and sent chat bubbles.
- **Accents:** *Hangat* (coral `#FF7A4D`) for warmth; *Nyala* (neon mint `#12E0A0`) strictly for
  **online / active / live / shared-interest** signals (never decorative).
- **Neutrals are warm, plum-tinted** — never cold gray. Light bg is a cream `#FCF7FB`; dark mode is a
  cozy **plum night** `#120B19`, not black.
- **Semantics:** success = mint, warning = amber, danger = soft red, info = blue.
- Full ramps + semantic aliases in `tokens/colors.css`. Both **light** (`:root`) and **dark**
  (`.dark` / `[data-theme="dark"]`) are defined; always style via the semantic aliases
  (`--surface-card`, `--text-strong`, `--brand-primary`, …) so both themes work for free.

### Typography
- **Display — Gabarito** (800/700): rounded-geometric, friendly, confident. Headlines, hero, names.
  Tight tracking (`-0.02 to -0.03em`).
- **Body/UI — Plus Jakarta Sans** (400–700): humanist geometric, *designed in Jakarta* — a deliberate
  cultural fit. All reading text, labels, inputs.
- **Mono — Space Mono** (400/700): eyebrows, the Hz/% "frequency readout" motif, timestamps, tiny meta.
  Always uppercase with wide tracking (`0.12em`) when used as an eyebrow.
- Body text never below 13px on mobile; minimum tap target 44px.

### Shape, radius & layout
- **Medium-rounded, balanced.** Controls/inputs `14px`, cards `20px`, profile cards/sheets `28px`,
  buttons & chips/tags **pill** (`999px`), avatars circular.
- 4px spacing grid (`tokens/spacing.css`). Screen padding ~20–24px. Generous vertical rhythm = the "cozy."
- Mobile-first: 390×844 phone frame; sticky bottom CTAs and a 4-item bottom tab bar.

### Elevation, shadows & glow
- **Warm, plum-tinted shadows** (`rgba(46,36,54,…)`), never neutral black. Soft and diffuse → cozy.
- **Neon glow is special:** `--glow-brand` / `--glow-pink` are reserved for brand-primary moments
  (primary button, active tab, selected chip, match modal, online dot). Don't glow everything.
- Cards: `surface-card` + 1px `border-subtle` + `shadow-sm`; featured cards add the brand glow.

### Backgrounds & imagery
- Most screens sit on the warm `--bg-base`; hero/celebration moments go **full-bleed aurora gradient**
  with a soft radial highlight on top.
- Photography is **warm, candid, real people** (lifestyle, natural light) — used full-bleed inside
  ProfileCards under a dark **protection scrim** so text/affordances stay legible.
- Decoration is sparse: floating glass interest chips on the welcome screen; no heavy patterns or textures.

### Motion
- Friendly and **springy**. `--ease-spring` (slight overshoot) for likes, chip toggles, switch thumbs.
- `--ease-out` for card/sheet transitions; `--ease-standard` for general UI.
- **Press = scale 0.96** (buttons) / `0.9` (icon buttons). Hover (where pointers exist) = subtle lift
  (`translateY(-2px)`) + stronger shadow.
- Swipe cards rotate slightly with drag and snap with `ease-out`. The LIVE dot pulses; match bars "tune up."
- Everything respects `prefers-reduced-motion` (durations collapse to 0).

### Transparency & blur
- Glassmorphism is used **only over imagery** (distance/online pills and interest chips on ProfileCards,
  `glass` IconButton) — `rgba(255,255,255,0.16)` + `backdrop-filter: blur(10px)`. Not on flat surfaces.

---

## ICONOGRAPHY

- **Library: [Lucide](https://lucide.dev)** — chosen for its rounded joins and even ~2px stroke, which
  match Gabarito/Plus-Jakarta's friendly-geometric feel. Loaded from CDN
  (`https://unpkg.com/lucide@0.460.0`). **This is a substitution** (no brand icon set existed); if you
  have a custom set, swap it and update this section.
- **Usage:** render `<i data-lucide="heart"></i>` and call `lucide.createIcons()` after mount
  (kits call it every render via `useLucide()`). Typical sizes 16/18/20/24px; color via `currentColor`.
- Common icons in use: `heart, x, star, sparkles, message-circle, users, flame, map-pin, search, send,
  plus, sliders-horizontal, badge-check, arrow-right/left, phone, mail, coffee, music, mountain`.
- **Brand logomark** is a hand-built SVG (`assets/logomark.svg` gradient, `assets/logomark-mono.svg`
  single-color) — the equalizer-to-peak waveform. The `Logomark` React helper lives in
  `ui_kits/_shared/shell.jsx`.
- **Emoji** appear only inside human content (chat, interest chips) — see Content Fundamentals. They are
  **not** part of the icon system and must never replace a Lucide icon in UI chrome.
- No PNG icons, no icon font beyond Lucide, no decorative unicode.

---

## INDEX / MANIFEST

**Root**
- `styles.css` — global entry (import this one file). `@import`s every token file.
- `readme.md` — this guide. · `SKILL.md` — Agent-Skill wrapper.

**`tokens/`** — `fonts.css` (Google Fonts CDN), `colors.css`, `typography.css`, `spacing.css`,
`radius.css`, `shadows.css`, `motion.css`, `base.css` (reset + `.sf-*` helpers).

**`assets/`** — `logomark.svg`, `logomark-mono.svg`.

**`guidelines/`** — foundation specimen cards (Design System tab): brand logo & gradients; color
scales (brand / accent / neutral / semantic / surfaces); type (display / body / mono / scale);
spacing, radius, elevation, motion.

**`components/`** — reusable primitives (namespace `window.SEFREKUENSIDesignSystem_629d2b`):
- `core/` — **Button**, **IconButton**
- `forms/` — **Input**, **Switch**
- `display/` — **Avatar**, **Badge**, **InterestTag**, **Card**
- `navigation/` — **Tabs** (segmented)
- `signature/` — **FrequencyMeter**, **ProfileCard**, **ChatBubble**, **RoomCard**

**`ui_kits/`** — full-screen recreations:
- `_shared/shell.jsx` — `PhoneShell`, `StatusBar`, `TabBar`, `Logomark`, `useLucide`
- `onboarding/` — Welcome → Login → Interests → Ready
- `discover/` — swipe deck + match modal + own profile (*dashboard pencarian teman*)
- `chat/` — chat list, 1:1 thread, room directory, live room thread

---

## Caveats / substitutions
- **Fonts** load from **Google Fonts CDN** (no licensed binaries were provided), so the compiler
  reports 0 self-hosted `@font-face`. They render fine online. To fully self-host, drop `.woff2`
  files in `assets/fonts/` and replace the `@import` in `tokens/fonts.css` with `@font-face` rules.
- **Logo** is an original wordmark/logomark built to brief — replace with the official asset if one exists.
- **Icons** are Lucide (substitution) — see Iconography.
- **Photos** in kits use Unsplash/Pravatar placeholders; swap for licensed brand imagery before production.
